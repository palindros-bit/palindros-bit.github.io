
import React, { useState, useEffect } from 'react';
import { BrewMethod, Recipe } from './types';
import { RECIPES } from './constants';
import BrewTimer from './components/BrewTimer';
import { getBrewTips } from './services/geminiService';

const App: React.FC = () => {
  const [selectedMethod, setSelectedMethod] = useState<BrewMethod | 'ALL' | 'FAVORITOS'>('ALL');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [showTimer, setShowTimer] = useState(false);
  const [aiTips, setAiTips] = useState<string[]>([]);
  const [loadingTips, setLoadingTips] = useState(false);
  
  // Color Verde Bosque: #1B4332
  const forestGreen = "#1B4332";

  // Estado para favoritos persistido en localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('filtrando_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('filtrando_favorites', JSON.stringify(favorites));
  }, [favorites]);

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const filteredRecipes = selectedMethod === 'ALL' 
    ? RECIPES 
    : selectedMethod === 'FAVORITOS'
      ? RECIPES.filter(r => favorites.includes(r.id))
      : RECIPES.filter(r => r.method === selectedMethod);

  useEffect(() => {
    if (selectedRecipe) {
      setLoadingTips(true);
      getBrewTips(selectedRecipe.name, selectedRecipe.method).then(tips => {
        setAiTips(tips);
        setLoadingTips(false);
      });
    }
  }, [selectedRecipe]);

  return (
    <div className="min-h-screen max-w-5xl mx-auto px-4 py-8 md:py-12">
      <header className="mb-12 text-center">
        <h1 className="grotesk text-5xl md:text-7xl text-[#2c1810] mb-4 tracking-tight lowercase">
          filtrando
        </h1>
        <p className="text-[#5b4636] text-lg max-w-xl mx-auto opacity-80 leading-relaxed">
          Recetas profesionales para café de especialidad. La precisión del barista en tus manos.
        </p>
      </header>

      {/* Filtro de Métodos */}
      <div className="flex flex-wrap justify-center gap-3 mb-12">
        <button
          onClick={() => setSelectedMethod('ALL')}
          className={`px-6 py-2 rounded-full transition-all text-sm font-semibold ${
            selectedMethod === 'ALL' 
            ? 'bg-[#2c1810] text-white shadow-lg' 
            : 'bg-white text-[#5b4636] border border-[#ede0d4] hover:border-[#d4a373]'
          }`}
        >
          Todos
        </button>
        {Object.values(BrewMethod).map(method => (
          <button
            key={method}
            onClick={() => setSelectedMethod(method)}
            className={`px-6 py-2 rounded-full transition-all text-sm font-semibold ${
              selectedMethod === method 
              ? 'bg-[#2c1810] text-white shadow-lg' 
              : 'bg-white text-[#5b4636] border border-[#ede0d4] hover:border-[#d4a373]'
          }`}
          >
            {method}
          </button>
        ))}
        <button
          onClick={() => setSelectedMethod('FAVORITOS')}
          style={{ 
            backgroundColor: selectedMethod === 'FAVORITOS' ? forestGreen : 'white',
            color: selectedMethod === 'FAVORITOS' ? 'white' : forestGreen,
            borderColor: selectedMethod === 'FAVORITOS' ? forestGreen : `${forestGreen}20`
          }}
          className={`px-6 py-2 rounded-full transition-all text-sm font-semibold flex items-center gap-2 border shadow-sm`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill={selectedMethod === 'FAVORITOS' ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
          Mis Favoritos
        </button>
      </div>

      {!selectedRecipe ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredRecipes.length > 0 ? (
            filteredRecipes.map(recipe => (
              <div 
                key={recipe.id}
                onClick={() => setSelectedRecipe(recipe)}
                className="group cursor-pointer bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-[#ede0d4] relative p-6 flex flex-col min-h-[220px]"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-[#fdfaf6] px-2 py-1 rounded-lg text-[10px] font-black text-[#2c1810] uppercase tracking-widest border border-[#ede0d4]">
                    {recipe.method}
                  </div>
                  <button 
                    onClick={(e) => toggleFavorite(e, recipe.id)}
                    className="p-1.5 transition-transform hover:scale-125"
                    style={{ color: favorites.includes(recipe.id) ? forestGreen : '#cbd5e1' }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={favorites.includes(recipe.id) ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </button>
                </div>
                
                <h3 className="text-xl font-bold text-[#2c1810] mb-1">{recipe.name}</h3>
                <p className="text-sm font-medium text-[#d4a373] mb-3">Por {recipe.author}</p>
                
                <p className="text-[#5b4636] text-sm line-clamp-2 opacity-80 mb-6 leading-relaxed flex-grow">
                  {recipe.description}
                </p>
                
                <div className="flex gap-4 text-xs font-bold text-[#2c1810]/60 border-t border-gray-100 pt-4">
                  <span>{recipe.coffeeGrams}g Café</span>
                  <span>{recipe.waterGrams}g Agua</span>
                  <span>{recipe.totalTime}</span>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full py-20 text-center">
              <div className="text-6xl mb-4">☕</div>
              <p className="text-[#5b4636] opacity-60 font-medium italic">No hay recetas que mostrar.</p>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-[2.5rem] overflow-hidden shadow-2xl border border-[#ede0d4]">
          <div className="md:flex">
            {/* Izquierda: Info */}
            <div className="md:w-1/2 p-8 md:p-12">
              <div className="flex justify-between items-center mb-10">
                <button 
                  onClick={() => setSelectedRecipe(null)}
                  className="text-[#d4a373] font-bold text-sm flex items-center hover:translate-x-[-4px] transition-transform"
                >
                  ← Volver a recetas
                </button>
                <button 
                  onClick={(e) => toggleFavorite(e, selectedRecipe.id)}
                  style={{ 
                    backgroundColor: favorites.includes(selectedRecipe.id) ? `${forestGreen}10` : '#f8fafc',
                    borderColor: favorites.includes(selectedRecipe.id) ? `${forestGreen}30` : '#f1f5f9',
                    color: favorites.includes(selectedRecipe.id) ? forestGreen : '#94a3b8'
                  }}
                  className={`p-2 rounded-full border hover:scale-110 transition-all`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={favorites.includes(selectedRecipe.id) ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </button>
              </div>
              
              <div className="mb-10">
                <span className="text-xs font-black text-[#d4a373] uppercase tracking-[0.2em]">
                  {selectedRecipe.method} • {selectedRecipe.author}
                </span>
                <h2 className="serif text-4xl font-bold text-[#2c1810] mt-2 leading-tight">
                  {selectedRecipe.name}
                </h2>
                <p className="mt-4 text-[#5b4636] opacity-80 leading-relaxed italic">
                  {selectedRecipe.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-10">
                <div className="p-4 bg-[#fdfaf6] rounded-2xl border border-[#ede0d4]/30">
                  <span className="block text-xs text-gray-400 uppercase font-bold mb-1">Café</span>
                  <span className="text-xl font-bold text-[#2c1810]">{selectedRecipe.coffeeGrams}g</span>
                </div>
                <div className="p-4 bg-[#fdfaf6] rounded-2xl border border-[#ede0d4]/30">
                  <span className="block text-xs text-gray-400 uppercase font-bold mb-1">Agua</span>
                  <span className="text-xl font-bold text-[#2c1810]">{selectedRecipe.waterGrams}g</span>
                </div>
                <div className="p-4 bg-[#fdfaf6] rounded-2xl border border-[#ede0d4]/30">
                  <span className="block text-xs text-gray-400 uppercase font-bold mb-1">Molienda</span>
                  <span className="text-xl font-bold text-[#2c1810] text-sm md:text-xl">{selectedRecipe.grindSize}</span>
                </div>
                <div className="p-4 bg-[#fdfaf6] rounded-2xl border border-[#ede0d4]/30">
                  <span className="block text-xs text-gray-400 uppercase font-bold mb-1">Temp.</span>
                  <span className="text-xl font-bold text-[#2c1810]">{selectedRecipe.temperature}</span>
                </div>
              </div>

              <button 
                onClick={() => setShowTimer(true)}
                className="w-full py-4 bg-[#2c1810] text-white rounded-2xl font-bold text-lg hover:bg-[#3d2116] transition-colors shadow-lg shadow-[#2c1810]/20 mb-10 flex items-center justify-center gap-3"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Iniciar Preparación
              </button>

              <div className="bg-[#faedcd]/30 p-6 rounded-2xl border border-[#faedcd]">
                <h4 className="text-sm font-bold text-[#2c1810] mb-3 flex items-center gap-2">
                  <span className="text-lg">✨</span> IA: Consejos de Barista
                </h4>
                {loadingTips ? (
                  <div className="flex gap-1 py-2">
                    <div className="w-1.5 h-1.5 bg-[#d4a373] rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-[#d4a373] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-[#d4a373] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  </div>
                ) : (
                  <ul className="space-y-3">
                    {aiTips.map((tip, i) => (
                      <li key={i} className="text-sm text-[#5b4636] leading-relaxed flex gap-3">
                        <span className="text-[#d4a373] font-bold">{i + 1}.</span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Derecha: Línea de Tiempo */}
            <div className="md:w-1/2 bg-[#f8f1e9] p-8 md:p-12 overflow-y-auto max-h-[800px]">
              <h3 className="text-xl font-bold text-[#2c1810] mb-8 border-b border-[#ede0d4] pb-4">Pasos a Seguir</h3>
              <div className="space-y-12">
                {selectedRecipe.steps.map((step, index) => (
                  <div key={index} className="relative pl-10">
                    <div className="absolute left-0 top-0 h-full w-[2px] bg-[#ede0d4]">
                      <div className="absolute top-0 left-[-7px] w-4 h-4 rounded-full bg-[#d4a373] border-4 border-[#f8f1e9]" />
                    </div>
                    <div className="mb-1 flex justify-between items-center">
                      <span className="text-xs font-bold text-[#d4a373] uppercase tracking-widest">
                        {Math.floor(step.time / 60)}:{(step.time % 60).toString().padStart(2, '0')}
                      </span>
                      {step.waterAmount && (
                        <span className="text-xs font-bold text-[#2c1810]/40">
                          {step.waterAmount}g Total
                        </span>
                      )}
                    </div>
                    <h4 className="text-lg font-bold text-[#2c1810] mb-2">{step.action}</h4>
                    <p className="text-[#5b4636] opacity-80 leading-relaxed text-sm italic">
                      {step.instruction}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <footer className="mt-20 pt-12 border-t border-[#ede0d4] text-center text-[#5b4636] opacity-60 text-sm">
        <p>&copy; {new Date().getFullYear()} filtrando. Fuentes: SCA, James Hoffmann, Tetsu Kasuya.</p>
        <p className="mt-2 font-medium">Pasión por el café de especialidad y la precisión técnica.</p>
      </footer>
    </div>
  );
};

export default App;
