
import React, { useState, useEffect, useCallback } from 'react';
import { Recipe, BrewStep } from '../types';

interface BrewTimerProps {
  recipe: Recipe;
  onClose: () => void;
}

const BrewTimer: React.FC<BrewTimerProps> = ({ recipe, onClose }) => {
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  useEffect(() => {
    let interval: any = null;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else if (!isActive && seconds !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  useEffect(() => {
    const nextStepIndex = recipe.steps.findIndex((step, idx) => {
      const nextStep = recipe.steps[idx + 1];
      return seconds >= step.time && (!nextStep || seconds < nextStep.time);
    });
    if (nextStepIndex !== -1) {
      setCurrentStepIndex(nextStepIndex);
    }
  }, [seconds, recipe.steps]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const currentStep = recipe.steps[currentStepIndex];
  const progress = (seconds / (recipe.steps[recipe.steps.length - 1].time + 30)) * 100;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div className="p-8 text-center bg-[#2c1810] text-white">
          <h2 className="text-xl font-medium opacity-80 mb-2">{recipe.name}</h2>
          <div className="text-6xl font-bold tracking-tighter mb-4 tabular-nums">
            {formatTime(seconds)}
          </div>
          <div className="flex justify-center gap-4">
            <button
              onClick={() => setIsActive(!isActive)}
              className={`px-8 py-2 rounded-full font-semibold transition-colors flex items-center gap-2 ${
                isActive ? 'bg-red-500 hover:bg-red-600' : 'bg-[#d4a373] hover:bg-[#c69566]'
              }`}
            >
              {isActive ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Pausar
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                  </svg>
                  Iniciar
                </>
              )}
            </button>
            <button
              onClick={() => { setSeconds(0); setIsActive(false); setCurrentStepIndex(0); }}
              className="px-8 py-2 rounded-full font-semibold border border-white/30 hover:bg-white/10 transition-colors"
            >
              Reiniciar
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-8">
            <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-[#d4a373] transition-all duration-1000"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-[#fdfaf6] p-6 rounded-2xl border border-[#ede0d4]">
              <div className="text-xs font-bold text-[#d4a373] uppercase tracking-wider mb-2">
                Acción Actual
              </div>
              <div className="text-2xl font-bold text-[#2c1810] mb-2 leading-tight">
                {currentStep?.action || 'Prepárate'}
              </div>
              <div className="text-[#5b4636] leading-relaxed text-sm">
                {currentStep?.instruction || 'Inicia el cronómetro cuando comiences a verter el agua.'}
              </div>
              {currentStep?.waterAmount && (
                <div className="mt-4 inline-flex items-center px-3 py-1 bg-[#2c1810] text-white rounded-lg text-xs font-bold uppercase tracking-wider">
                   Objetivo: {currentStep.waterAmount}g
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-gray-100">
              <button 
                onClick={onClose}
                className="text-gray-500 hover:text-gray-800 font-bold text-sm transition-colors"
              >
                Cerrar
              </button>
              <div className="text-xs text-gray-400 font-medium">
                Paso {currentStepIndex + 1} de {recipe.steps.length}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrewTimer;
