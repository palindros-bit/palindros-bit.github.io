
import { BrewMethod, Recipe } from './types';

export const RECIPES: Recipe[] = [
  {
    id: 'v60-hoffmann',
    name: 'V60: Técnica Definitiva',
    author: 'James Hoffmann',
    method: BrewMethod.V60,
    coffeeGrams: 30,
    waterGrams: 500,
    temperature: '98°C - 100°C',
    grindSize: 'Medium-Fine',
    totalTime: '3:30',
    description: 'Un método fiable y repetible que produce alta extracción y claridad.',
    steps: [
      { time: 0, action: 'Bloom (Preinfusión)', waterAmount: 60, instruction: 'Vierte 60g de agua, agita suavemente para saturar todo el café.' },
      { time: 45, action: 'Primer Vertido', waterAmount: 300, instruction: 'Vierte hasta 300g con un movimiento circular constante.' },
      { time: 75, action: 'Vertido Final', waterAmount: 500, instruction: 'Vierte el resto del agua (hasta 500g) antes del minuto 1:15.' },
      { time: 105, action: 'Agitar y Girar', instruction: 'Remueve una vez suavemente, luego dale al V60 un giro final mientras drena.' },
      { time: 210, action: 'Finalización', instruction: 'Espera a que termine de drenar. Busca una cama de café plana.' }
    ]
  },
  {
    id: 'v60-rao',
    name: 'V60: Método Rao',
    author: 'Scott Rao',
    method: BrewMethod.V60,
    coffeeGrams: 20,
    waterGrams: 340,
    temperature: '97°C',
    grindSize: 'Medium-Fine',
    totalTime: '3:00',
    description: 'Técnica enfocada en evitar canales (channeling) y maximizar la uniformidad.',
    steps: [
      { time: 0, action: 'Bloom y Excavación', waterAmount: 60, instruction: 'Vierte 60g y usa una cuchara para asegurar que todo el café esté húmedo.' },
      { time: 45, action: 'Vertido Único', waterAmount: 340, instruction: 'Vierte todo el agua restante de forma constante.' },
      { time: 100, action: 'Giro de Rao', instruction: 'Levanta el V60 y dale un giro suave para que el café no se pegue a las paredes.' },
      { time: 180, action: 'Finalización', instruction: 'El café debería terminar con una superficie totalmente plana.' }
    ]
  },
  {
    id: 'v60-kasuya',
    name: 'Método 4:6',
    author: 'Tetsu Kasuya',
    method: BrewMethod.V60,
    coffeeGrams: 20,
    waterGrams: 300,
    temperature: '92°C',
    grindSize: 'Coarse',
    totalTime: '3:30',
    description: 'Ajusta el dulzor y la fuerza dividiendo el agua en porciones del 40% y 60%.',
    steps: [
      { time: 0, action: '1er Vertido', waterAmount: 50, instruction: 'Vierte 50g. Este vertido define el dulzor inicial.' },
      { time: 45, action: '2do Vertido', waterAmount: 120, instruction: 'Vierte hasta 120g para equilibrar la acidez.' },
      { time: 90, action: '3er Vertido', waterAmount: 180, instruction: 'Vierte hasta 180g para dar cuerpo.' },
      { time: 135, action: '4to Vertido', waterAmount: 240, instruction: 'Vierte hasta 240g.' },
      { time: 180, action: '5to Vertido', waterAmount: 300, instruction: 'Vertido final.' },
      { time: 210, action: 'Finalización', instruction: 'Espera el drenaje total.' }
    ]
  },
  {
    id: 'aeropress-hoffmann',
    name: 'AeroPress: Receta Definitiva',
    author: 'James Hoffmann',
    method: BrewMethod.AEROPRESS,
    coffeeGrams: 11,
    waterGrams: 200,
    temperature: '100°C',
    grindSize: 'Fine',
    totalTime: '2:30',
    description: 'Método no invertido diseñado para la simplicidad y la consistencia.',
    steps: [
      { time: 0, action: 'Vertido total', waterAmount: 200, instruction: 'Añade todo el agua inmediatamente. Pon el émbolo encima para sellar el vacío.' },
      { time: 120, action: 'Agitar', instruction: 'Agita suavemente el AeroPress para que baje la costra de café.' },
      { time: 150, action: 'Presionar', instruction: 'Presiona lenta y suavemente hasta abajo. Para cuando escuches el siseo.' }
    ]
  },
  {
    id: 'aeropress-adler',
    name: 'AeroPress: El Original',
    author: 'Alan Adler',
    method: BrewMethod.AEROPRESS,
    coffeeGrams: 15,
    waterGrams: 200,
    temperature: '80°C',
    grindSize: 'Fine',
    totalTime: '1:15',
    description: 'La receta del creador del AeroPress: rápida, a baja temperatura y muy suave.',
    steps: [
      { time: 0, action: 'Vertido Corto', waterAmount: 100, instruction: 'Vierte agua hasta el número 2 del AeroPress.' },
      { time: 10, action: 'Remover', instruction: 'Remueve durante 10 segundos vigorosamente.' },
      { time: 20, action: 'Presionar', instruction: 'Presiona suavemente. Luego añade agua caliente al resultado (estilo Americano).' }
    ]
  },
  {
    id: 'aeropress-cafeshi',
    name: 'AeroPress: Expresivo y Rápido',
    author: 'Cafeshi',
    method: BrewMethod.AEROPRESS,
    coffeeGrams: 18,
    waterGrams: 200,
    temperature: '90°C',
    grindSize: 'Medium',
    totalTime: '1:30',
    description: 'Cuerpo intenso y dulzor marcado, ideal para beber solo o con un toque de leche.',
    steps: [
      { time: 0, action: 'Método Invertido', waterAmount: 100, instruction: 'Vierte 100g de agua y remueve vigorosamente 10 veces.' },
      { time: 30, action: 'Vertido Final', waterAmount: 200, instruction: 'Completa hasta los 200g. Coloca el filtro enjuagado.' },
      { time: 60, action: 'Voltear y Presionar', instruction: 'Voltea con cuidado sobre tu taza y presiona con fuerza constante.' }
    ]
  },
  {
    id: 'french-press-hoffmann',
    name: 'Prensa Francesa: Sin Presión',
    author: 'James Hoffmann',
    method: BrewMethod.FRENCH_PRESS,
    coffeeGrams: 30,
    waterGrams: 500,
    temperature: '95°C',
    grindSize: 'Medium-Coarse',
    totalTime: '9:00',
    description: 'Se centra en un café de inmersión limpio y sin sedimentos.',
    steps: [
      { time: 0, action: 'Vertido', waterAmount: 500, instruction: 'Vierte los 500g de agua. Deja reposar 4 minutos.' },
      { time: 240, action: 'Romper Costra', instruction: 'Remueve la parte superior suavemente. Retira la espuma y restos flotantes con cucharas.' },
      { time: 300, action: 'Espera Paciente', instruction: 'Espera otros 5-8 minutos para que los sedimentos bajen. No bajes el émbolo todavía.' },
      { time: 540, action: 'Servir', instruction: 'Coloca el émbolo justo en la superficie y sirve con extrema suavidad.' }
    ]
  },
  {
    id: 'french-press-flatwhite',
    name: 'Prensa Francesa: Textura Sedosa',
    author: 'Flat & White',
    method: BrewMethod.FRENCH_PRESS,
    coffeeGrams: 20,
    waterGrams: 300,
    temperature: '92°C',
    grindSize: 'Coarse',
    totalTime: '5:00',
    description: 'Método equilibrado para quienes buscan el cuerpo clásico de la prensa sin amargor excesivo.',
    steps: [
      { time: 0, action: 'Bloom', waterAmount: 60, instruction: 'Moja todo el café y espera 30 segundos.' },
      { time: 30, action: 'Inmersión Total', waterAmount: 300, instruction: 'Vierte el resto del agua con fuerza para mezclar bien.' },
      { time: 240, action: 'Presión Parcial', instruction: 'Baja el émbolo solo hasta la mitad para no comprimir los posos.' },
      { time: 300, action: 'Servir', instruction: 'Sirve inmediatamente para evitar sobre-extracción.' }
    ]
  },
  {
    id: 'clever-standard',
    name: 'Inmersión Estándar',
    author: 'Barista Hustle',
    method: BrewMethod.CLEVER,
    coffeeGrams: 20,
    waterGrams: 300,
    temperature: '94°C',
    grindSize: 'Medium',
    totalTime: '4:00',
    description: 'Facilidad de inmersión con la limpieza de un filtro de papel.',
    steps: [
      { time: 0, action: 'Agua Primero', waterAmount: 300, instruction: 'Vierte todo el agua primero, luego añade el café encima para evitar obstrucciones.' },
      { time: 30, action: 'Remover', instruction: 'Remueve suavemente la superficie para asegurar que todo esté húmedo.' },
      { time: 120, action: 'Segundo Removido', instruction: 'Un pequeño giro a los 2 minutos ayuda a una extracción uniforme.' },
      { time: 180, action: 'Drenaje', instruction: 'Coloca la Clever sobre un servidor para iniciar el filtrado.' }
    ]
  },
  {
    id: 'clever-cafeshi',
    name: 'Clever: Dulzor Intenso',
    author: 'Cafeshi',
    method: BrewMethod.CLEVER,
    coffeeGrams: 15,
    waterGrams: 250,
    temperature: '91°C',
    grindSize: 'Medium-Fine',
    totalTime: '3:30',
    description: 'Resalta notas de chocolate y caramelo usando una molienda ligeramente más fina.',
    steps: [
      { time: 0, action: 'Infusión', waterAmount: 250, instruction: 'Café primero, luego agua en círculos lentos.' },
      { time: 60, action: 'Turbulencia', instruction: 'Remueve circularmente 3 veces con una cuchara.' },
      { time: 150, action: 'Drenaje', instruction: 'Coloca en la taza. El flujo debería ser constante.' }
    ]
  }
];
