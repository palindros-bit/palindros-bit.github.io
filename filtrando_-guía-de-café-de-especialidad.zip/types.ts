
export enum BrewMethod {
  V60 = 'V60',
  CLEVER = 'Clever Dripper',
  FRENCH_PRESS = 'French Press',
  AEROPRESS = 'AeroPress'
}

export interface BrewStep {
  time: number; // in seconds
  action: string;
  waterAmount?: number; // cumulative water
  instruction: string;
}

export interface Recipe {
  id: string;
  name: string;
  author: string;
  method: BrewMethod;
  coffeeGrams: number;
  waterGrams: number;
  temperature: string;
  grindSize: 'Fine' | 'Medium-Fine' | 'Medium' | 'Medium-Coarse' | 'Coarse';
  totalTime: string;
  steps: BrewStep[];
  description: string;
}

export interface BrewSessionState {
  isActive: boolean;
  currentStepIndex: number;
  elapsedSeconds: number;
  recipe: Recipe | null;
}
