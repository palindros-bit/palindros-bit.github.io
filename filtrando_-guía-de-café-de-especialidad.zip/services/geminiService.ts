
import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export async function getBrewTips(recipeName: string, method: string): Promise<string[]> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide 3 expert troubleshooting tips for the ${recipeName} coffee brewing method (${method}). Focus on common mistakes and how to fix them for better flavor.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["tips"]
        }
      }
    });

    const data = JSON.parse(response.text || '{"tips": []}');
    return data.tips || [];
  } catch (error) {
    console.error("Error fetching tips from Gemini:", error);
    return [
      "Ensure your water is filtered for the best clarity.",
      "Check your grind size if the drawdown is too fast or slow.",
      "Preheat your brewing vessel to maintain temperature stability."
    ];
  }
}
